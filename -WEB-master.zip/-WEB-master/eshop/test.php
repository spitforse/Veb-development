<?php
	$name = 'name';
		$email = 'dsdssds';
		$phone = 'dsdssds';
		$adress = 'dsdssds';
		$filename = $basket['orderid'];
		$str = "$name;$email;$phone;$adress;\n";
	printf($str);
	printf($str);
?>