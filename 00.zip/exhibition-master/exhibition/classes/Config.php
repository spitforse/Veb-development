<?php

abstract class Config
{
    const HOST = 'exhibition';
    const DB_NAME = 'exhibition';
    const DB_USER = 'root';
    const DB_PASSWORD = '';
}