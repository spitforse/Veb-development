<?php


class hallMap extends BaseMap
{

}