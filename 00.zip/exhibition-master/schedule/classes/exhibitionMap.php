<?php


class exhibitionMap extends BaseMap
{

}