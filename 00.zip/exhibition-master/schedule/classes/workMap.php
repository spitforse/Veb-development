<?php


class workMap extends BaseMap
{

}