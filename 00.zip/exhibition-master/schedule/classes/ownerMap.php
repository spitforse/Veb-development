<?php


class ownerMap extends BaseMap
{

}